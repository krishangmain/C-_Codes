#include <iostream>
using namespace std;
int main(){
 /*int a=10;	
cout<<a<<endl;

char b ='v';
cout<<b<<endl;

bool parth =true;
cout<<parth<<endl;

float parth1 = 1.266;
cout<<parth1<<endl;

double parth2=5.7656858776578587;
cout<<parth2<<endl;

int size =sizeof(parth2);
 cout<<size<<endl;

int c ='a';
cout<<c<<endl;

char d =98;
cout<<d<<endl;

float e=5.0/2;
cout<<e<<endl;
*/
char ch;
cout<<"enter the ch"<<endl;

cin>>ch;

if(ch= a to z){
	cout<<"letter is in smaller case"<<endl;
}

	}