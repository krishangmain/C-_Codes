#include<iostream>
using namespace std;
int main(){
int a = 10;
float f=10;
double d=10;
bool b=10;
cout<<sizeof(a)
cout<<&a<<endl;
return 0;
}