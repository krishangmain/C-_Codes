#include<iostream>
using namespace std;
int main(){
	char ch;
cout<<"enter the ch"<<endl;

cin>>ch;

if(char ch = a to z){
	cout<<"letter is in smaller case"<<endl;
}
	return 0;
}
