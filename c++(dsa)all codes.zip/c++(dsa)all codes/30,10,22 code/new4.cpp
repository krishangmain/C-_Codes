#include <iostream>
using namespace std;
int main(){
	int n;
	cin>>n;
	int arr[10];
	int i=10;i<=10;++i;
		cout<<i<<" ";
	
cout<<endl;
	return 0;

}