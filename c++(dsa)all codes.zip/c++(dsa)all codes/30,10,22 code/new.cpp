#include<iostream>
using namespace std;
int main(){
int num=0;
int c;
while (num<=300){
	float c=(5.0/9)*(num-32);
	cout<<c<<endl;
	num=num+20;
}

return 0;

}