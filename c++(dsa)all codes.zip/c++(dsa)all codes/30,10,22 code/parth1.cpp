#include<iostream>
using namespace std;
int main(){
	unsigned int k,j,h;
	k=-3;
	j=2;
	h=-1;
	cout<<k<<endl;
	cout<<j<<endl;
	cout<<h<<endl;
	return 0;
}