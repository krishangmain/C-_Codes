#include <iostream>
using namespace std;
int main(){

int n=7,i=2;


	for(i=2;i<n/2;i++){
if (n%i==0){
	
		cout<<"not prime"<<endl;
		break;

}
	
	
cout<<"prime"<<endl;


}
}