#include<bits/stdc++.h>
using namespace std;
int main(){
	char arr[100];
	gets (arr);
	
	return 0;
}