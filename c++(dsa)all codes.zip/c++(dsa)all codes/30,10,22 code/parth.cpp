#include <iostream>

using namespace std;

int main()
{
       cout<<"hello parth and garv"<<endl;
	return 0;
}