#include<bits/stdc++.h>
using namespace std;
int main(){
	int rem;
	int num;
	int b;
	cin>>rem>>num

	return 0;
}